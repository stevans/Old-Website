import ds9
from scipy import *

#Normalize zoom
ds9.set("zoom to fit")

#zoom in
for i in range(20):
  ds9.set("zoom 1.1")
  ds9.wait(0.1)

#zoom out
for i in range(20):
  ds9.set("zoom 0.9")
  ds9.wait(0.1)