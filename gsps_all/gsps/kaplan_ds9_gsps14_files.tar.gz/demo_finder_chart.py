import ds9

object = raw_input('Enter name object: ')
imgsize = raw_input('Enter size of image on a side in arcmin: ')

ds9.set('colorbar no')
ds9.set('dsssao size '+imgsize+' '+imgsize+' arcmin')
ds9.set('dsssao name {' + object+'}')
ds9.set('dsssao close')
ds9.set('scale log') #Set to log scale
ds9.set('scale Zmax') #Set scale limits t`o Zmax, looks okay
ds9.set('zoom to fit')
half_imgsize_arcsec = str(round(60.0*float(imgsize)/2.0))
ds9.draw('#compass('+half_imgsize_arcsec+'",'+half_imgsize_arcsec+'",30) {N} {E} fixed=0 color=red')
ds9.set('grid on')
ds9.set('grid type publication')
ds9.set('grid sky fk5')
ds9.set('grid title def no')
ds9.set('grid title text {'+object+'}')
ds9.set('grid numerics type exterior')
ds9.set('grid numerics color black')
ds9.set('grid axes type exterior')
ds9.set('zoom 0.7')
ds9.set('saveimage eps finderchart.eps')
