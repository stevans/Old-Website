import ds9
from scipy import *

crosshair_coords = ds9.get("crosshair wcs fk5 sexagesimal")
ds9.draw('cross point  '+crosshair_coords+' # text={'+crosshair_coords+'} color=yellow')