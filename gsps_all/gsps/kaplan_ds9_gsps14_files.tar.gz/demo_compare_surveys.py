import ds9

object = raw_input('Enter name object: ')
imgsize = raw_input('Enter size of image on a side in arcmin: ')

#load near-infrared image
ds9.set('2mass survey k')
ds9.set('2mass size '+imgsize+' '+imgsize+' arcmin') 
ds9.set('2mass name {'+object+'}')
ds9.set('2mass close')
ds9.set('scale log') #Set to log scale
ds9.set('scale Zmax') #Set scale limits t`o Zmax, looks okay

print 'oh no what happened!'

#load optical image
ds9.set('frame new')
ds9.set('dsssao size '+imgsize+' '+imgsize+' arcmin')
ds9.set('dsssao name {' + object+'}')
ds9.set('dsssao close')
ds9.set('scale log') #Set to log scale
ds9.set('scale Zmax') #Set scale limits t`o Zmax, looks okay
ds9.set('zoom to fit')
ds9.set('lock frame wcs')