import ds9

#Rotate once
for i in range(72): 
  ds9.set("rotate 5.0")
  ds9.wait(0.1)

#Rotate once
for i in range(72): 
  ds9.set("rotate 5.0")
  ds9.wait(0.1)

